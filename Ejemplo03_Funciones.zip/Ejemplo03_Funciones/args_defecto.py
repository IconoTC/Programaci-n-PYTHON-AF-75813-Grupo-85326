print(1,2,3,4,5, sep=" - ", end=".\n")

def datos_trabajador(nombre, estado_civil="Soltero", sueldo=24000):
    print(nombre, "esta", estado_civil, "gana", sueldo)
    
datos_trabajador("Maria")
datos_trabajador("Juan",53000)  # Por posicion, interpreta que 53000 es el estado_civil
datos_trabajador(sueldo=40000, nombre="Felipe")  # keywords, se puede cambiar el orden
datos_trabajador(nombre="Juan",sueldo=53000)
datos_trabajador("Juan", "Casado", 53000)

'''
    En Python se pueden pasar los argumentos de 2 formas:
        - por posicion: respetar el orden de los argumentos
        - keywords: es anteponer el nombre del argumento
'''

'''
    Crear una funcion que reciba:
        - datos como numero variable de argumentos (texto)
        - separador que por defecto sera " | "
    y retorne los datos recibido unidos por el separador en una cadena (la clase str tiene el metodo join)
'''

def concatenar(*datos: str, separador=" | "):   # datos es una tupla, es una coleccion iterable
    return separador.join(datos)

print(concatenar('1','2','3','4','5'))
print(concatenar('1','2','3','4','5', separador=", "))
print(concatenar('1','2','3','4','5', separador=" "))
# print(concatenar(separador=" - ", '1','2','3','4','5'))   ERROR, no puedo alterar el orden