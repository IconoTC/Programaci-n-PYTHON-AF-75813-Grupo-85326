'''
    Crear una funcion que recibe un texto y retorna:
        - el texto en mayusculas
        - el texto en minusculas
        - la longitud del texto
'''

def procesar_texto(texto: str):
    # param = str(texto)
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud

# recoger el resultado con multiples variables
txtMay, txtMin, txtLen = procesar_texto("Buenos dias")
print(txtMay)
print(txtMin)
print(txtLen)

# recoger el resultado con una coleccion del tipo tupla
tupla = procesar_texto("Buenos dias")
print(tupla)
for dato in tupla:
    print(dato)
