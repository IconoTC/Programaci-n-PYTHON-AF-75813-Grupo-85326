# Funcion con un numero variable de argumentos
def sumar(*numeros):   # numeros es una tupla
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(9))
print(sumar(9,5))
print(sumar(9,5,2))
print(sumar(9,5,2,4))

'''
    crear una funcion que recibe el nombre y las notas del alumno
    utilizando la funcion sumar() calcular la nota media
    devolver el nombre en mayusculas y la nota media
'''

def procesar_notas(nombre, *notas):   # El numero variable de argumentos al final
    # sumar(notas) estoy enviando una tupla
    # sumar(*notas) estoy enviando los elementos de la tupla
    nota_media = sumar(*notas) / len(notas)
    return nombre.upper(), round(nota_media,2)

print(procesar_notas("Juan", 2,5,3))
print(procesar_notas("Maria", 9,8))
print(procesar_notas("Pedro", 7,6,9,4,5))