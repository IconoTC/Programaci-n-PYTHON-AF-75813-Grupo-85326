import pickle

# Abrir el fichero en modo lectura y binario
fichero = open("Ejemplo12_Ficheros_Binarios/fichero.pckl", "rb")

# Leer el contenido
frutas = pickle.load(fichero)

# Mostrar el contenido y tipo
print(frutas)
print(type(frutas))  # <class 'set'>

# cerrar el fichero
fichero.close()