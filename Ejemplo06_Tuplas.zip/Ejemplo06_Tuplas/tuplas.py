# tuplas: Colecciones ordenadas (con indice) pero son inmutables
# No permite agregar, modificar, eliminar
# Se permiten elementos duplicados
# se crean con ()
# Ejemplos: meses, dias de la semana, estado civil, puntos cardinales, ....

# Tuplas de varias dimensiones tambien funcionan
# slices funcionan igual que las listas
# operadores de pertenencia: in y not in

dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(type(dias))   # <class 'tuple'>
print(dias)

# crear tupla vacia
tupla_vacia = ()
tupla = tuple()

# Recorrer la tupla por item
for item in dias:
    print(item, end=" ")
print()

# Recorrer la tupla por indice
for idx in range(len(dias)):
    print(dias[idx], end=" ")
print()

# Intento borrar el lunes
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# Concatenar tuplas
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# mas_dias = dias + ('sabado')  # TypeError: can only concatenate tuple (not "str") to tuple, no funciona si la tupla tiene un solo elemento
# mas_dias = dias + ('sabado', 'domingo') # Funciona si la otra tupla tiene mas de un elemento
mas_dias = dias + ('sabado', ) # le engañamos al interprete para que piense que hay mas de un elemento
print(mas_dias)

# Interpreta que es un str
prueba = ('uno')
# Interpreta que es una tupla
prueba = ('uno',)
print(prueba)
print(type(prueba))

# Longitud de la tupla
print(len(mas_dias))
print(mas_dias.__len__())

# Cuantos sabados hay
print("Sabados:", mas_dias.count("sabado"))

# En que posicion esta el viernes
print("Posicion viernes:", mas_dias.index("viernes"))

# Otra forma de crear tuplas
tupla = 1,2,3,4,5
print(type(tupla))

# Multiplicar tuplas, tambien se puede hacer con otras colecciones
resultado = tupla * 2
print(resultado)   # (1, 2, 3, 4, 5, 1, 2, 3, 4, 5)

# Tambien funciona con otras colecciones
print("Minimo:", min(tupla))
print("Maximo:", max(tupla))
print("Suma:", sum(tupla))

# Convertir una tupla en lista
lista_dias = list(mas_dias)
print(type(lista_dias))  # <class 'list'>

# Convertir una lista en tupla
nueva_tupla = tuple(lista_dias)
print(type(nueva_tupla))  # <class 'tuple'>
