# Ejemplo 1
# crear una tupla con el cuadrado de cada numero
numeros = (1,2,3,4,5)

# <generator object <genexpr> at 0x105ce8450>
tupla_cuadrados = (num ** 2 for num in numeros)

# En las tuplas es necesario crearlas con tuple(), sino entiende que es un generador
tupla_cuadrados = tuple(num ** 2 for num in numeros)
print(tupla_cuadrados)


# Ejemplo 2
# crear una tupla con pares (dia,longitud) de todos los elementos de dias que comienzan por m
# ( ('martes',6), ('miercoles',9) )
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
tupla_dias = tuple( (dia, len(dia))  for dia in dias  if dia[0]=='m')
print(tupla_dias)