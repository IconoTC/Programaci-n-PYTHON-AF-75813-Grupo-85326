''' Crear una excepcion personalizada '''

# Version minima
#class NegativoError(Exception):
#   pass

class NegativoError(Exception):
    def __init__(self, msg) -> None:
        self.mensaje = msg
        
    def getMensaje(self):
        return self.mensaje
    
    
try:
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # raise (throw) lanza la excepcion
        # Las excepciones personalizadas hay que lanzarlas de forma manual
        raise NegativoError("La edad no puede ser negativa")
except Exception as error:
    print("Se produjo un error")
    print(error)