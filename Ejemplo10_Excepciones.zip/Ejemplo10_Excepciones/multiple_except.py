# try-except-else-finally

import traceback

datos = ['1', 'dos', '3', '4', '5']
suma = 0

for idx in range(len(datos) + 1):
    try:
        # acceder al dato
        dato = datos[idx]
        
        # lo convertimos en numero
        numero = int(dato)
    except (ValueError, IndexError, Exception) as ex:
        print("Error de tipo", type(ex))
        print("Mensaje de error", ex)
        traceback.print_exc()
    else:
        # sumamos el numero
        suma += numero
        
print("Suma:", suma)