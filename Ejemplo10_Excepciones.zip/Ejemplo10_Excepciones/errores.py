# try-except-else-finally

import traceback

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ValueError as ex:
    # ex recoge el mensaje de error
    print("El valor introducido no es numerico", ex)
    traceback.print_exc()
except ZeroDivisionError as error:
    print("No se puede dividir por cero", error)
    traceback.print_exc()
except:   # el bloque except mas general, va al final
    # Se ejecuta cuando hay error
    print("Ha ocurrido un error")
    # Mostrar la traza
    traceback.print_exc()
else:
    # Se ejecuta cuando no hay ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya o no errores
    print("****** FIN ******")
    
# Estructuras minimas que compilan
try:
    pass
except:
    pass

try:
    pass
finally:
    pass