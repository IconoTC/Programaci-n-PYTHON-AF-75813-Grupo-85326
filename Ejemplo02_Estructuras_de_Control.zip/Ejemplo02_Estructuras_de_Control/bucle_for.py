nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres:
    print(item, end=" ")
print()


''' rangos '''
# range(inicio, final, salto)  el numero final no esta incluido
# Mostrar los numeros del 0 al 9
for numero in range(10):    # Rango va desde 0 hasta numero-1
    print(numero, end=" ")
print()   

# Mostrar los numeros del 1 al 10
for numero in range(1, 11):    
    print(numero, end=" ")
print()  

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):    
    print(numero, end=" ")
print()  

# Mostrar los numeros del 10 al 1 decreciente
for numero in range(10, 0, -1):    
    print(numero, end=" ")
print()

# Mostrar los numeros del 10 al 0 decreciente de 2 en 2
for numero in range(10, 0, -2):    
    print(numero, end=" ")
print()

# Mostrar los nombres de la lista por posicion
for indice in range(len(nombres)):  # genera un rango del 0 al 4
    print(nombres[indice], end=" ")
print()