# mostrar los numeros del 1 al 10
num = 1
while num <= 10:
    print(num, end = " ")
    num += 1
print()

# recorrer una lista
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
indice = 0
while indice < len(nombres):
    print(nombres[indice],end=" ")
    indice += 1
print()