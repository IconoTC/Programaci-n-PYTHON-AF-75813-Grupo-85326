'''
    Generar numero aleatorio entre 0 y 10
    tratar de adivinarlo dando pistas
'''
import random
numero = random.randint(0,10)
acertado = False

while not acertado:
    prueba = int(input("Adivina numero (0-10): "))
    if prueba > numero:
        print("Te has pasado, prueba con un numero menor")
    elif prueba < numero:
        print("Te has quedado corto, prueba con un numero mayor")
    else:
        print("Enhorabuena, has acertado")
        acertado = True