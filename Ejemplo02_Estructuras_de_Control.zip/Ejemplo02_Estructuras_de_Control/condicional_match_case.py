'''
    El usuario introduce una letra (l,m,x,j,v,s,d)
    Mostrar el dia de la semana correspondiente
    o "Dia no valido"
    Puede ser que la letra se introduzca en minuscula o mayuscula
    Ideas: or, upper(), lower(), in
'''

letra = input("Introduce una letra (l,m,x,j,v,s,d): ")

match letra:
    case 'l' | 'L':
        print("Es lunes")
    case 'm' | 'M':
        print("Es martes")
    case 'x' | 'X':
        print("Es miercoles")
    case 'j' | 'J':
        print("Es jueves")
    case 'v' | 'V':
        print("Es viernes")
    case 's' | 'S':
        print("sabado")
    case 'd' | 'D':
        print("domingo")
    case _:   # Actua como default
        print("Dia no valido")
