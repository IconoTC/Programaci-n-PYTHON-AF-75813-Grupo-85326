texto = "bienvenidos al curso de Python"

print(texto.capitalize()) # solo la primera letra en mayuscula y el resto en minusculas
print(texto.title())  # mayuscula la primera letra de cada palabra
print(texto.upper())  # todo el texto en mayusculas
print(texto.lower()) # todo el texto en minusculas
print(texto.swapcase())  # intercambia mayusculas por minusculas y viceversa

print("isalnum", texto.isalnum()) # True si solo hay letras y numeros, False cualquier otro caracter
print("isalnum", "hola".isalnum())  # True
print("isalnum", "1234".isalnum())  # True
print("isalnum", "hola1234".isalnum()) # True
print("isalnum", "hola_1234".isalnum())  # False

print("isalpha", texto.isalpha()) # True si solo hay letras, False cualquier otro caracter
print("isalpha", "hola".isalpha())  # True
print("isalpha", "1234".isalpha())  # False
print("isalpha", "hola1234".isalpha()) # False
print("isalpha", "hola_1234".isalpha())  # False

print("isdigit", texto.isdigit()) # True si solo hay numeros, False cualquier otro caracter
print("isdigit", "hola".isdigit())  # False
print("isdigit", "1234".isdigit())  # True
print("isdigit", "hola1234".isdigit()) # False
print("isdigit", "hola_1234".isdigit())  # False

print("isupper", texto.isupper()) # True si solo hay mayusculas, ignora el resto de caracteres
print("isupper", "HOLA".isupper())  # True
print("isupper", "1234".isupper())  # False
print("isupper", "HOLA1234".isupper()) # True
print("isupper", "HOLA_1234".isupper())  # True

print("islower", texto.islower()) # True si solo hay minusculas, ignora el resto de caracteres
print("islower", "hola".islower())  # True
print("islower", "1234".islower())  # False
print("islower", "Hola1234".islower()) # False
print("islower", "hola_1234".islower())  # True

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())  # __ indica que es privado pero se puede acceder y funciona

# La tabla ASCII esta ordenada (1º numeros, 2º mayusculas, 3º minusculas)
print("max", max(texto)) # El caracter con mas valor dentro de la tabla ASCII
print("min", min(texto))  # El caracter con menos valor muestra el " "

ejemplo = "   Hoy es lunes    "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n")  # Elimina los espacios de la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n")  # Elimina los espacios de la derecha
print("strip", ejemplo.strip(), end=".\n")  # Elimina los espacios de la izquierda y la derecha
prueba = "......hola......"
print("strip", prueba.strip("."), end=".\n")

palabras = texto.split() # Por efecto trocea la cadena por el espacio en blanco
print(type(palabras))   # <class 'list'>
print(palabras)
fecha = "24/11/2025"
lista = fecha.split("/")
print(lista)

print("replace", texto.replace("e", "E"))  # Reemplaza todas las letras e por E
print("replace", texto.replace("e", "E", 1))  # Solo reemplaza la primera letra e que encuentra

# Los indices siempre empiezan en 0
print("find", texto.find("o"))  # retorna el indice donde encuentra la primera letra o
print("find", texto.find("o", 10))   # Empieza a buscar a partir del indice 10
print("find", texto.find("o", 10, 20)) # Empieza a buscar a partir del indice 10 hasta el 19, el ultimo esta excluido
print("rfind", texto.rfind("o")) # Empieza a buscar por la derecha

