# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 2
print("Resto o modulo:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)
print("Division:", numero1 / numero2)
print("Division entera:", numero1 // numero2)

# Operadores de asignacion (+=,-=,*=,/=,%=,**=,//=)
numero1 += 5       # numero1 = numero1 + 5 

# En Python no existen incrementos y decrementos
numero1 += 1   # numero1++
numero1 -= 1   # numero1--

# Operadores de comparacion (<,>,<=,>=,==,!=)
print(numero1 < numero2)  # False
print(numero1 == numero2)  # False
print(numero1 != numero2)  # True

# Operadores de identidad (is, is not)
# Sirven para verificar si es el mismo objeto
num1 = 6
num2 = 6
print("Es el mismo objeto", num1 is num2)  # True

nombres1 = ["Juan","Maria"]
nombres2 = ["Juan","Maria"]
print("Es el mismo objeto", nombres1 is nombres2)  # False
print("Son iguales las listas?", nombres1 == nombres2)

# Operadores de pertenencia (in, not in)
print("Luis esta en nombres?", "Luis" in nombres1) # False
print("Maria esta en nombres?", "Maria" in nombres1) # True
print("Luis no esta en nombres?", "Luis" not in nombres1) # True