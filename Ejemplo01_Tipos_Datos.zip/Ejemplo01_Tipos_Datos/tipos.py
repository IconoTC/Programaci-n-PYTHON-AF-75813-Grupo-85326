'''
    Comentarios de Bloque (Docstring)
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros (int)
numero1 = 8
numero2 = 4
suma = numero1 + numero2
print(type(suma))  # <class 'int'>
# TypeError: can only concatenate str (not "int") to str
# print("suma: " + suma)
print("suma:" + str(suma))
print("suma:", suma)

# numeros reales (float)
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print(type(triangulo))  # <class 'float'>
print("Area del triangulo:", triangulo)
# round(numero, num_decimales)
print("Area del triangulo:", round(triangulo, 2))

# booleanos: True o False (bool)
resuelto = True
print(type(resuelto))  # <class 'bool'>
print("Problema resuelto?", resuelto)

# Cadenas de texto (str)
# se pueden utilizar comillas dobles o simples
nombre = "Juan"
apellido = 'Lopez'
print(type(nombre))  # <class 'str'>
print(nombre, apellido)
print(nombre, apellido, sep="-", end=".\n")