'''
    leer la informacion del fichero.txt y generar una copia.txt (w+t)
    mostrar el contenido de copia.txt
'''

# Abrir el fichero en modo lectura
fichero_lectura = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero en modo escritura
fichero_escritura = open("Ejemplo11_Ficheros_Texto/copia.txt", "w+t", encoding="utf-8")

for linea in fichero_lectura.readlines():
    fichero_escritura.write(linea)
    
# leer copia.txt
fichero_escritura.seek(0)
for linea in list(fichero_escritura):
    print(linea, end="")
    
# cerrar los 2 ficheros
fichero_lectura.close()
fichero_escritura.close()