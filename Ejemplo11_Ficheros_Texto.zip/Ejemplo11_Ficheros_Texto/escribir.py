# Abrir el fichero en modo escritura
fichero = open("Ejemplo11_Ficheros_Texto/fichero.txt", "wt", encoding="utf-8")

# Solicitar texto al usuario hasta que introduzca FIN
texto = ""
while texto != "FIN":
    texto = input("Introduce texto, (FIN) para terminar:")
    if texto == "FIN":
        break
    else:
        fichero.write(texto)
        fichero.write("\n")

# cerrar el fichero
fichero.close()