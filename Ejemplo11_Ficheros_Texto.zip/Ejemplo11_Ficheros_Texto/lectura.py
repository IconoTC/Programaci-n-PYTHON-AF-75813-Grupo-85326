# Abrir el fichero en modo lectura
fichero = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Leer todo el contenido del fichero
texto = fichero.read()
print(texto)

# Leer todo el contenido y lo proceso linea a linea
# mover el puntero o cursor al primer caracter
fichero.seek(0)
lista = fichero.readlines()
for linea in lista:
    print(linea.upper(), end="")
    
# Otra forma
fichero.seek(0)
for linea in list(fichero):
    print(linea.upper(), end="")
    
# Otra forma
fichero.seek(0)
for linea in fichero:
    print(linea.upper(), end="")
    
# cerrar el fichero
fichero.close()