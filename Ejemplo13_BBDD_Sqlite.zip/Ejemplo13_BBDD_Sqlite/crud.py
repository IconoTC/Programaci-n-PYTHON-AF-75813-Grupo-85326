import sqlite3

# Abrir la conexion
conexion = sqlite3.connect("Ejemplo13_BBDD_Sqlite/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

'''  ******* Insert *******  '''
# Insertar 2 productos a traves de una query:
#      1, Pantalla, 129.95
#      2, Scanner, 450.75
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

# Insertar 4 productos a traves de una query parametrizada:
#      3, Teclado, 29.95
#      4, Raton, 18.90
#      5, Impresora, 89.25
#      6, Auriculares, 230
lista = [(3, 'Teclado', 29.95), (4, 'Raton', 18.90), (5, 'Impresora', 89.25), (6, 'Auriculares', 230)]
query = "insert into PRODUCTOS values (?, ?, ?)"
#cursor.executemany(query, lista)


'''  ******** Consultas *********  '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()   # recoger todos los resultados de la query
for prod in productos:
    print(prod)
print("------------------")
    
# consultar todos los productos con precio inferior a 50
productos = cursor.execute("select * from PRODUCTOS where precio < 50")
for prod in productos:
    print(prod)
print("------------------")

# consultar todos los productos cuya descripcion sea Impresora
#productos = cursor.execute("select * from PRODUCTOS where descripcion = 'Impresora' ")
dato = input("Introduce descripcion a buscar: ")
parametro = tuple([dato])
productos = cursor.execute("select * from PRODUCTOS where descripcion = ?", parametro)
for prod in productos:
    print(prod)
print("------------------")

# consultar todos los productos ordenados por precio ascendente
productos = cursor.execute("select * from PRODUCTOS ORDER by precio")
for prod in productos:
    print(prod)
print("------------------")

# consultar todos los productos ordenados por precio descendente
productos = cursor.execute("select * from PRODUCTOS ORDER by precio DESC")
for prod in productos:
    print(prod)
print("------------------")

# consultar todos los productos comiencen por letra R
parametro = ('R%',)
productos = cursor.execute("select * from PRODUCTOS where descripcion LIKE ?", parametro)
for prod in productos:
    print(prod)
print("------------------")

# consultar todos los productos que contienen la letra e y el precio es inferior a 50
parametros = ('%e%', 50)
productos = cursor.execute("select * from PRODUCTOS where descripcion LIKE ? and precio < ?", parametros)
for prod in productos:
    print(prod)
print("------------------")
  
  
'''  ******** Modificar *********  '''  
# subir un 10% el precio de la impresora
parametro = ('Impresora',)
productos = cursor.execute("update PRODUCTOS set precio = precio * 1.1 where descripcion = ?", parametro)
conexion.commit()

# Cambiar la descripcion de raton a raton inalambrico
parametros = ('Raton inalambrico', 'Raton')
productos = cursor.execute("update PRODUCTOS set descripcion=? where descripcion=?", parametros)
conexion.commit()

'''  ******** Eliminar *********  '''
# Borrar todos los scanner
parametro = ('Scanner',)
productos = cursor.execute("delete from PRODUCTOS where descripcion = ?", parametro)
    
# IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la BBDD
conexion.close()