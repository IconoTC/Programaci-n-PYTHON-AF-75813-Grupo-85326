# Ejemplo 1
# crear un diccionario donde utilizando las vocales
#   - la clave es el indice de la lista
#   - el valor es la letras
indices = {idx:'aeiou'[idx]  for idx in range(len('aeiou'))}
print(indices)


# Ejemplo 2
# crear un diccionario con numeros del 1 al 5 y sus cuadrados
numeros = { num:num**2  for num in range(1,6)}
print(numeros)