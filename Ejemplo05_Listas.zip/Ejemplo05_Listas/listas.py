# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de diferente tipo
# permiten elementos duplicados
# se crean []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]
print(list1)
print(list2)

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas
lista = list1 + list2  # el orden es importante
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud:", len(lista))
print("Longitud:", lista.__len__())

# Acceso a los elementos de la lista
# indice es positivo comienza por el primero, por la izquierda, el primero es 0
print(lista[2])  # 28010
# indice es negativo comienza por el ultimo, por la derecha
# empieza a contar desde -1
print(lista[-2])  # soltera

# Agregar elementos al final -> append
lista.append('morena')
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez al final -> extend
lista.extend( [1,2,3] )   # los elementos tienen que ir en una coleccion: lista,tupla,...
print(lista)

# Eliminar elementos por posicion
del lista[0]  # Elimina el elemento que esta en el indice 0 -> primera posicion
print(lista)

# Eliminar por elemento, busca el elemento y el primero que encuentra lo borra
lista.remove(3)   # Elimina el valor 3 de la lista
print(lista)

# Buscar un elemento y me retorna el indice donde se encuentra
indice = lista.index('Perez')
print(indice)

# Mostrar cuantas soltera hay
print("Cuantas soltera?", lista.count("soltera"))

# Invertir la lista
lista.reverse()
print(lista)

# Ordenar o clasificar listas
colores = ['rojo', 'verde', 'azul', 'amarillo']
print(sorted(colores))  # La muestra ordenada pero no la modifica
print(colores)
print(sorted(colores, reverse=True))  # La ordena de forma descendente

# Ordena la lista y la modifica
colores.sort()
print(colores)

# Establecer el orden, p.e. longitud de cada elemento
print(sorted(colores, key=lambda dato: len(dato)))
'''
def mi_funcion(dato):
    len(dato)
'''

# Eliminar todos los elementos de la lista
colores.clear()
print(colores)

''' slices [begin:stop:step]  '''
# mostrar todos los elementos de la lista
print("Todos:", lista[:])

# mostrar los ultimos 4 elementos
print("Ultimos 4:", lista[-4:])

# Mostrar los elementos del indice 3 al 6
print("Indice 3 al 6:", lista[3:7])   # el ultimo no entra, igual que en los rangos

# Mostrar los elementos del indice 6 al 3
print("Indice 6 al 3:", lista[6:2:-1])

# mostrar todos los elementos en orden inverso
print("Todos inverso:", lista[::-1])

# mostrar todos los elementos en orden inverso de 2 en 2
print("Todos inverso:", lista[::-2])
