# conjuntos: colecciones sin orden (no tenemos indices)
# NO permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Se crean con {}
# IMPORTANTE: conjunto = {}  lo interpreta como diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas))  # <class 'set'>
print(frutas)

# Conjunto vacio
conjunto = {}
print(type(conjunto)) # <class 'dict'>
conjunto = set()
print(type(conjunto)) # <class 'set'>

# Agregar elementos al conjunto
frutas.add('fresas')
print(frutas)

# Eliminar un elemento
frutas.remove('platano')
print(frutas)

# Para recorrer conjuntos lo hacemos solo por item
for item in frutas:
    print(item, end=" ")
print()

# Retorna un elemento al azar y lo saca del conjunto
print(frutas.pop())
print(frutas)

# Comprobar si existe un elemento
print('platano' in frutas)
print('manzana' in frutas)
print('melon' not in frutas)

# copiar un conjunto en otro
# funciona con listas pero no con tuplas
otro = frutas.copy()
print(otro)

# Borrar todos los elementos del conjunto
frutas.clear()
print(frutas)