numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes en ambos conjuntos
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# diferencia de conjuntos: elementos de un conjunto que no estan en el otro
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# El orden importa
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# union de conjuntos: todos los elementos de ambos, sin repetir los comunes
print(numeros1.union(numeros2))
print(numeros1 | numeros2)

# diferencia simetrica de conjuntos: la union - la interseccion
print(numeros1.symmetric_difference(numeros2))
print(numeros1 ^ numeros2)

'''  estas operaciones modifican el conjunto, las anteriores no   '''
# modificar un conjunto con diferencia de conjuntos: borra los elementos de un conjunto que estan en el otro
# El orden es importante
numeros1.difference_update(numeros2)
numeros1 -= numeros2
print(numeros1)
print(numeros2)

# modificar con union de conjuntos: modifica el conjunto uniendo los elementos del otro conjunto
# El orden es importante
numeros1.update(numeros2)
numeros1 |= numeros2
print(numeros1)
print(numeros2)