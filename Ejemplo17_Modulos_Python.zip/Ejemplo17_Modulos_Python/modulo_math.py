# Este modulo contiene constantes y funciones para operaciones matematicas

# importar el modulo math
#import math
from math import *

# pi
print("PI:", pi)

# e
print("E:", e)

# seno de 90
print("SENO:", sin(radians(90)))

# coseno de 90
print("COSENO:", cos(radians(90)))

# log base 10 del numero 12345.567
print("log base 10:", log(12345.567, 10))
print("log base 10:", log10(12345.567))

# log base 2 del numero 12345.567
print("log base 2:", log(12345.567, 2))
print("log base 2:", log2(12345.567))

# potencia de 2 elevado a 8
print("2 elevado 8:", pow(2,8))
print("2 elevado 8:", 2 ** 8)

# exponente de e elevado a 5
print("e elevado a 5:", exp(5))
print("e elevado a 5:", pow(e,5))

# redondeo al alza 3.89  -> 4
print("redondeo al alza 3.89:", ceil(3.89))

# redondeo al alza 3.19  -> 4
print("redondeo al alza 3.19:", ceil(3.19))

# redondeo a la baja 3.89  -> 3
print("redondeo a la baja 3.89:", floor(3.89))

# redondeo a la baja 3.19  -> 3
print("redondeo a la baja 3.19:", floor(3.19))

# truncar 3.89  -> 3
print("truncar 3.89:", trunc(3.89))

# truncar 3.19  -> 3
print("truncar 3.19:", trunc(3.19))

# factorial de 4
print("factorial de 4:", factorial(4))