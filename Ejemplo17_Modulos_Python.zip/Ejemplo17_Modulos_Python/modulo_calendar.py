# Este modulo contiene funciones para manejar calendarios

# importar el modulo
import calendar
import locale

# mostrar el calendario de 2025
print(calendar.calendar(2025, c=10, m=4))

# mostrar el calendario de mayo de 2025
print(calendar.month(2025, 5))

# mostrar el calendario de mayo de 2025 pero que comience en domingo
calendar.setfirstweekday(6)
print(calendar.month(2025, 5))

# Los dias de la semana:
# solo con una letra
print(calendar.weekheader(1))
# con 2 letras
print(calendar.weekheader(2))
# 3 letras
print(calendar.weekheader(3))

# Mostrar si 2024 es bisiesto
print("2024 es bisiesto", calendar.isleap(2024)) # True
# Mostrar si 2025 es bisiesto
print("2025 es bisiesto", calendar.isleap(2025)) # False

# Con el modulo locale podemos obtener el calendario en español
l_es = locale.setlocale(locale.LC_ALL, "es_ES")
c = calendar.LocaleTextCalendar(locale=l_es)
print(c.formatmonth(2025, 5))