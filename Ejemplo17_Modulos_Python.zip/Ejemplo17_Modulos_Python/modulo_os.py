# Este modulo contiene funciones para trabajar con el sistema operativo

# importar modulo
import os

# coger fecha y hora del sistema
print(os.system('date'))

# Mostrar en que directorio o carpeta estais ubicados
print(os.getcwd())

# 2.- Borrar la carpeta
#os.rmdir('Ejemplo16_Modulos_Python/mi_carpeta')

# 1.- Crear una carpeta
os.mkdir('Ejemplo16_Modulos_Python/mi_carpeta')

# Mover a esa carpeta
os.chdir('Ejemplo16_Modulos_Python/mi_carpeta')

# Ejecutar un comando ms-dos (mkdir, rmdir, dir)
os.system('mkdir otra_carpeta')
os.system('mkdir otra_mas')

# Mostrar los directorios desde una carpeta
print(os.listdir())