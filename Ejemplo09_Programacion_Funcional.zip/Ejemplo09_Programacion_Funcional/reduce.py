# La funcion reduce le pasamos una coleccion
# retorna un solo resultado
# La funcion ha de tener 2 parametros:
#   - el primero actua como acumulador
#   - el segundo es el valor recibido
# sintaxis:   reduce(funcion, coleccion)

'''  Para utilizar reduce hay que importarla  '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

def sumar(acum, num):
    # la primera vez que se invoca se le pasan 2 argumentos: 3,8
    return acum + num   # lo guarda en acum y lo retorna al final

print("Suma: ", reduce(sumar, numeros))


# Ejemplo 2
nombres = ['Juan', 'Maria', 'Pedro']
# retornar una cadena con los nombres en mayusculas y separados "-"

def concatenar(resultado, nombre):
    return resultado.upper() + "-" + nombre.upper()

print(reduce(concatenar, nombres))