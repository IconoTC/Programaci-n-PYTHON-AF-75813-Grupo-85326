# la funcion map, se aplica sobre una coleccion donde
# con cada elemento se invoca a otra funcion que lo modifica
# o devuelve uno nuevo
# Importante, la funcion debe retornar un elemento
# sintaxis:   map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(num):
    return num * 2

numeros_dobles = list(map(duplicar, numeros))
print(numeros_dobles)
print(numeros)  # la coleccion original no se modifica

# Ejemplo 2
# Retornar un diccionario donde a cada alumno le subimos un punto
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)

def sumar_punto(alum):
    return alum[0], alum[1] + 1

nuevas_notas = dict(map(sumar_punto, alumnos.items()))
print(nuevas_notas)


# Ejemplo 3
from modulo_persona import persona
personas = [persona('Juan',27), persona('Maria',15), persona('Pedro',21)]

# Crear otra lista de personas con el nombre en mayuscula y un año mas
def modificar_persona(per: persona):
    per.nombre = per.nombre.upper()
    per.edad += 1
    return per

personas_2 = list(map(modificar_persona, personas))
for p in personas_2:
    print(p)
print("-----------------")
for p in personas:
    print(p)
print("-----------------")