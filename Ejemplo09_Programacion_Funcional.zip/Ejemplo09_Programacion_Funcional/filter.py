# La funcion filter se aplica sobre una coleccion
# a través de otra funcion filtramos los elementos
# la funcion tiene que devolver un valor booleano:
#   - True: el elemento pasa el filtro, nos lo quedamos
#   - False: no pasa el filtro y lo descartamos
# sintaxis:  filter(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def solo_pares(num):
    # return num % 2 == 0
    if num % 2 == 0:
        return True
    else:
        return False
    
numeros_pares = list(filter(solo_pares, numeros))
print(numeros_pares)

# Ejemplo 2
# Retornar un diccionario con los alumnos suspensos
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)

def suspensos(alum):
    if alum[1] < 5:
        return True
    else:
        return False
    
alumnos_suspensos= dict(filter(suspensos, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
from modulo_persona import persona
personas = [persona('Juan',27), persona('Maria',15), persona('Pedro',21)]

# Crear otra lista con los menores de edad
def menores(per: persona):
    if per.edad < 18:
        return True
    else:
        return False

personas_menores = list(filter(menores, personas)) 
for p in personas_menores:
    print(p)