class persona:
    def __init__(self, nombre:str, edad:int) -> None: 
        self.nombre = nombre
        self.edad = edad
        
    def __eq__(self, otra: object) -> bool:
        if self.nombre == otra.nombre and self.edad == otra.edad :
            return True
        else:
            return False
        
    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)