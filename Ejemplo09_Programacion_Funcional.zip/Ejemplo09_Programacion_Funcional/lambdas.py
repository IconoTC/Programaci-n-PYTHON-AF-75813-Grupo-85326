# Sintaxis:  lambda parametros: cuerpo de la funcion

'''  ****************** map ***************  '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numeros_dobles = list(map(lambda num: num * 2, numeros))
print(numeros_dobles)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
nuevas_notas = dict(map(lambda alum: (alum[0], alum[1] + 1), alumnos.items()))
print(nuevas_notas)

# Ejemplo 3
from modulo_persona import persona
personas = [persona('Juan',27), persona('Maria',15), persona('Pedro',21)]
personas_2 = list(map(lambda per: persona(per.nombre.upper(),per.edad + 1), personas))
for p in personas_2:
    print(p)
print("-----------------")
for p in personas:
    print(p)
print("-----------------")

'''  ****************** fiter ***************  '''
# Ejemplo 1
numeros = [3,8,4,15,30]
numeros_pares = list(filter(lambda num: num % 2 == 0, numeros))
print(numeros_pares)

# Ejemplo 2
alumnos = dict(Juan=6.4, Maria=4.3, Luis=6.4, Adolfo=3.1)
alumnos_suspensos= dict(filter(lambda alum: alum[1] < 5, alumnos.items()))
print(alumnos_suspensos)

# Ejemplo 3
from modulo_persona import persona
personas = [persona('Juan',27), persona('Maria',15), persona('Pedro',21)]
personas_menores = list(filter(lambda per: per.edad < 18, personas)) 
for p in personas_menores:
    print(p)
    
    
'''  ****************** reduce ***************  '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]
print("Suma: ", reduce(lambda acum, num: acum + num , numeros))


# Ejemplo 2
nombres = ['Juan', 'Maria', 'Pedro']
print(reduce(lambda resultado, nombre: resultado.upper() + "-" + nombre.upper(), nombres))
