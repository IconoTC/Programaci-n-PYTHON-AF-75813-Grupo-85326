import pandas as pd

# https://pandas.pydata.org/docs/

datos = ['Juan', 'Pedro', 'Estefania', 'Ana', 'Esteban'] 
serie = pd.Series(datos, dtype="string")
print(serie)

print("Longitud:", serie.size)
print("Indices:", serie.index)

# Acceso a los elementos
print(serie[0:2]) # muestra los 2 primeros, el ultimo indice no entra
print(serie[-2:]) # muestra los 2 ultimos
print(serie[3])   # solo muestra el que esta en el indice 3
print(serie[ [1,4] ])  # muestra los elementos del indice 1 y del 4


# Aplicar un lambda a una serie
serie = serie.apply(lambda nombre: nombre.upper())
print(serie)