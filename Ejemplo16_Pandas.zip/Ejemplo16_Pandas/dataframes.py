import pandas as pd

# crear el dataframe
datos = [ ['Juan',4.5], ['Pedro',8.9], ['Estefania', 1.4], ['Ana', 5.6], ['Esteban', 7.8] ]
columnasNombres = ['Nombre', 'Nota']
filas = list(range(5))
df = pd.DataFrame(datos, columns=columnasNombres, index=filas)
print(df)

print(df.info)
print(df.shape)  # (5, 2)
print(df.size)   #  10  = 5 x 2
print("Nombres columnas", df.columns)
print("Indices", df.index)
print(df.head(2))

# Mostrar los datos de una columna (Serie)
print(df['Nombre'])
print(df.Nombre)

# Mostrar los datos de una fila (loc)
print(df.loc[2])  # muestra la fila con indice 2

# Mostrar un valor (fila, columna) iloc
print(df.iloc[4,1])  # Nota de Esteban, esta en la fila con indice 4 y la nota en la columna con indice 1

# Filtrar por Esteban y mostrar su nota
notaEsteban = df[df['Nombre'] == 'Esteban']['Nota']      # df[filtro]['columna']
print(notaEsteban)

# Agregar nueva columna
resultados = ['Suspenso', 'Aprobado', 'Suspenso', 'Aprobado', 'Aprobado']
df.insert(loc=1, column="Resultado", value=resultados)
print(df)

# Agrupaciones
print(df.groupby('Resultado').size())
print(df.groupby('Resultado').count())

# Borrar
df = df.drop(['Resultado'], axis=1)   # axis = 1  borro columnas
df = df.drop([4], axis=0)   # axis = 0  borro filas,  Elimino  a Esteban