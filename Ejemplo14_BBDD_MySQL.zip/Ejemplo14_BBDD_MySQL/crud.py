import mysql.connector

# Al abrir la conexion
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="indra"
)

# Obtener un cursor
cursor = conexion.cursor()

'''  ******* Insert *******  '''
# Insertar 2 productos a traves de una query:
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla', 129.95)")
#cursor.execute("insert into PRODUCTOS values (2, 'Scanner', 450.75)")

# Insertar 4 productos a traves de una query parametrizada:
lista = [(3, 'Teclado', 29.95), (4, 'Raton', 18.90), (5, 'Impresora', 89.25), (6, 'Auriculares', 230)]
query = "insert into PRODUCTOS values (%s, %s, %s)"
#cursor.executemany(query, lista)


'''   ******** Consultas *********  '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()   # recoger todos los resultados de la query
for prod in productos:
    print(prod)
print("------------------")

   
# consultar todos los productos con precio inferior a 50
cursor.execute("select * from PRODUCTOS where precio < 50")
for prod in cursor.fetchall():
    print(prod)
print("------------------")


# consultar todos los productos cuya descripcion sea Impresora
dato = input("Introduce descripcion a buscar: ")
parametro = tuple([dato])
cursor.execute("select * from PRODUCTOS where descripcion = %s", parametro)
for prod in cursor.fetchall():
    print(prod)
print("------------------")


# consultar todos los productos ordenados por precio ascendente
cursor.execute("select * from PRODUCTOS ORDER by precio")
for prod in cursor.fetchall():
    print(prod)
print("------------------")


# consultar todos los productos ordenados por precio descendente
cursor.execute("select * from PRODUCTOS ORDER by precio DESC")
for prod in cursor.fetchall():
    print(prod)
print("------------------")


# consultar todos los productos comiencen por letra R
parametro = ('R%',)
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s", parametro)
for prod in cursor.fetchall():
    print(prod)
print("------------------")


# consultar todos los productos que contienen la letra e y el precio es inferior a 50
parametros = ('%e%', 50)
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s and precio < %s", parametros)
for prod in cursor.fetchall():
    print(prod)
print("------------------")
  

'''  ******** Modificar *********  '''
# subir un 10% el precio de la impresora
parametro = ('Impresora',)
cursor.execute("update PRODUCTOS set precio = precio * 1.1 where descripcion = %s", parametro)
conexion.commit()

# Cambiar la descripcion de raton a raton inalambrico
parametros = ('Raton inalambrico', 'Raton')
cursor.execute("update PRODUCTOS set descripcion=%s where descripcion=%s", parametros)
conexion.commit()

 
'''  ******** Eliminar *********  '''
# Borrar todos los scanner
parametro = ('Scanner',)
cursor.execute("delete from PRODUCTOS where descripcion = %s", parametro)


# IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la BBDD
conexion.close()