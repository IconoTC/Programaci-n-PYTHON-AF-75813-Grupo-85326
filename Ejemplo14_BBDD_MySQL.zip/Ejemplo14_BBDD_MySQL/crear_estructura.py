''' Crear la tabla  '''

import mysql.connector

# Al abrir la conexion
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="indra"
)

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla de PRODUCTOS
cursor.execute("CREATE TABLE PRODUCTOS (codigo integer PRIMARY KEY, descripcion varchar(50), precio double)")

# IMPORTANTE EL COMMIT
conexion.commit()

# Cerrar la BBDD
conexion.close()