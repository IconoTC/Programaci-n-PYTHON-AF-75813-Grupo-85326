class persona:
    def __init__(self, nombre:str, edad:int) -> None: 
        self.nombre = nombre
        self.edad = edad
        
    def __eq__(self, otra: object) -> bool:
        if self.nombre == otra.nombre and self.edad == otra.edad :
            return True
        else:
            return False
        
    def __str__(self) -> str:
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)
    
class empleado(persona):
    def __init__(self, nombre: str, edad: int, sueldo: float) -> None:
        # Enviamos el nombre y la edad al constructor de la superclase
        super().__init__(nombre, edad)
        self.sueldo = sueldo
        
    def __str__(self) -> str:
        # super().__str__() llama al __str__ de la superclase
        return  "{}, sueldo {}".format(super().__str__(), self.sueldo)  
    
pers = persona("Manuel", 48)
print(pers)

empleado = empleado("Guadalupe", 32, 45000)
print(empleado)

# Comprobar la igualdad de los objetos
p1 = persona("Manuel", 48)
p2 = persona("Manuel", 48)
print("Son iguales?", p1 == p2)