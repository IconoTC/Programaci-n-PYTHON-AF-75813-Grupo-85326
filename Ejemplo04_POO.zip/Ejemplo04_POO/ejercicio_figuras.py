'''
    Crear una clase Figura con propiedades: x,y
    metodo calcular_area 
    metodo __str__ que retorne [x,y]
    
    Crear las clases Circulo, Triangulo y Rectangulo
    necesitareis nuevos atributos o propiedades
    sobreescribir el metodo calcular_area
    
    crear instancias de cada figura, mostrar el area y la posicion [x,y]
'''
import math
class figura:
    def __init__(self, x,y) -> None:
        self.x = x
        self.y = y
        
    def calcular_area(self):
        pass
    
    def __str__(self) -> str:
        return "[{},{}]".format(self.x, self.y)
    
class circulo(figura):
    def __init__(self, x, y, radio) -> None:
        super().__init__(x, y)
        self.radio = radio
        
    def calcular_area(self):
        return math.pi * math.pow(self.radio, 2)
    
class triangulo(figura):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y)
        self.base = base
        self.altura = altura
        
    def calcular_area(self):
        return self.base * self.altura / 2

class rectangulo(triangulo):
    def __init__(self, x, y, base, altura) -> None:
        super().__init__(x, y, base, altura)    
    
    def calcular_area(self):
        return self.base * self.altura  
        
c = circulo(10,20, 4.56)
print("Posicion:", c)
print("Area del circulo: ", c.calcular_area())

t = triangulo(8,4, 50,25)
print("Posicion:", t)
print("Area del triangulo: ", t.calcular_area())

r = rectangulo(30,15, 50,30)
print("Posicion:", r)
print("Area del rectangulo: ", r.calcular_area())