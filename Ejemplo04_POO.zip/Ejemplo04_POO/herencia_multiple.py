class animal:
    def __init__(self, nombre, edad) -> None:
        self.__nombre = nombre
        self.__edad = edad
        
    def __str__(self) -> str:
        return "Nombre: {} Edad: {}".format(self.__nombre, self.__edad)
    
class producto_venta:
    def __init__(self, codigo, precio) -> None:
        self.__codigo = codigo
        self.__precio = precio
        
    def __str__(self) -> str:
        return "Codigo: {} Precio: {}".format(self.__codigo, self.__precio)
    
class perro(animal, producto_venta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo) -> None:
        # Podemos llamar al constructor por el nombre de la clase pero es necesario enviar puntero self
        animal.__init__(self, nombre, edad)
        producto_venta.__init__(self, codigo, precio)
        self.__vacunado = vacunado
        self.__sexo = sexo
        
    def __str__(self) -> str:
        return  "{} {} Vacunado: {} Sexo: {}".format(
            animal.__str__(self), producto_venta.__str__(self), self.__vacunado, self.__sexo )  
        
p = perro("Fifi",3,"PE-001",295.90,True,"Macho")
print(p)