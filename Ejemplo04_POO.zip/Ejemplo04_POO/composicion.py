class direccion:
    def __init__(self, calle: str, numero: int, poblacion:str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
    
    def info(self):
        # Mayor, 5 (Madrid)
        return "{}, {} ({})".format(self.calle, self.numero, self.poblacion)  
        

class persona:
    # Composicion es cuando una clase tiene propiedades de otra clase
    def __init__(self, nombre:str, edad:int, direccion:direccion) -> None:   # -> None no retorna nada
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
        
    def mostrar_info(self):
        print("Me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion.info()))

# Crear el objeto direccion de Juan
dir_juan = direccion("Mayor", 5, "Madrid")
      
# crear objetos o instancias de persona
p1 = persona("Juan", 23, dir_juan) # En p1 guardamos al direccion de memoria del objeto que acabamos de crear
p2 = persona("Maria", 18, direccion("Diagonal", 189, "Barcelona"))

p1.edad += 1
p1.mostrar_info()
p2.mostrar_info()