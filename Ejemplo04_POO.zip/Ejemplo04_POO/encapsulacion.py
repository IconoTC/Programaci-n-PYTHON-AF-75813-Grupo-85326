class fecha_publica:
    
    def __init__(self, dia, mes, anyo) -> None:
        self.dia = dia
        self.mes = mes
        self.anyo = anyo
    
    # sobrescribo el metodo heredado de object
    # Este metodo se llama de forma automatica cada vez que mostramos la fecha   
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.dia, self.mes, self.anyo)
        
    
hoy = fecha_publica(25,11,2025)
print(hoy)
erronea = fecha_publica(98,1234,-56)
print(erronea)


# Una clase encapsulada define todas sus propiedades como privadas
# y se accede a ellas a través de los métodos get y set públicos
class fecha:
    
    def __init__(self, dia, mes, anyo) -> None:
        self.set_dia(dia)
        self.set_mes(mes)
        self.set_anyo(anyo)
    
    def get_dia(self):
        return self.__dia
    
    def set_dia(self, dia):
        # los dias son validos del 1 al 31
        if dia > 0 and dia <= 31:
            # creamos la propiedad privada
            self.__dia = dia
        else:
            self.__dia = 0
            
    def get_mes(self):
        return self.__mes
    
    def set_mes(self, mes):
        # los meses son validos del 1 al 12
        if mes > 0 and mes <= 12:
            # creamos la propiedad privada
            self.__mes = mes
        else:
            self.__mes = 0
    
    def get_anyo(self):
        return self.__anyo
    
    def set_anyo(self, anyo):
        # los años son validos 2025 y 2026
        if anyo == 2025 or anyo == 2026:
            # creamos la propiedad privada
            self.__anyo = anyo
        else:
            self.__anyo = 0
            
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.__dia, self.__mes, self.__anyo)
    
hoy = fecha(25,11,2025)
print(hoy)
erronea = fecha(98,1234,-56)
print(erronea)