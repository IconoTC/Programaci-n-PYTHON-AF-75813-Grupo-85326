class persona:
    # constructor o inicializador
    def __init__(self, nombre:str, edad:int) -> None:   # -> None no retorna nada
        #pass  # significa que el cuerpo esta vacio
        # self.nombre y self.edad son atributos o propiedades o campos de la instancia o del objeto de persona
        self.nombre = nombre
        self.edad = edad
        
    # un metodo es una funcion que pertenece a una clase
    # cuando el metodo recibe el puntero self hace que sea una metodo de instancia
    def mostrar_info(self):
        print("Me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
# crear objetos o instancias de persona
p1 = persona("Juan", 23) # En p1 guardamos al direccion de memoria del objeto que acabamos de crear
p2 = persona("Maria", 18)

p1.edad += 1
p1.mostrar_info()
p2.mostrar_info()