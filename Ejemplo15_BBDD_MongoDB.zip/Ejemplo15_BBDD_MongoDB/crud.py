from pymongo import MongoClient

# Al abrir la conexion
conexion = MongoClient("mongodb://localhost:27017")

# Usamos la BBDD tiendaDB
db = conexion['tiendaDB']

# Usamos la coleccion PRODUCTOS
coleccion = db['PRODUCTOS']

'''  ******* Insert *******  '''
# Insertar 2 productos uno a uno:
#coleccion.insert_one( {"codigo":1, "descripcion":"Pantalla", "precio":129.95} )
#coleccion.insert_one( {"codigo":2, "descripcion":"Scanner", "precio":450.75} )


# Insertar 4 productos:
lista = [
    {"codigo":3, "descripcion":"Teclado", "precio":29.95},
    {"codigo":4, "descripcion":"Raton", "precio":18.90},
    {"codigo":5, "descripcion":"Impresora", "precio":89.25},
    {"codigo":6, "descripcion":"Auriculares", "precio":230}
]
#coleccion.insert_many(lista)


'''    ******** Consultas *********   '''
# consultar todos los productos
for prod in coleccion.find():
    print(prod)
print("------------------")

# consultar todos los productos con precio inferior a 50
for prod in coleccion.find( {"precio": {"$lt":50} } ):
    print(prod)
print("------------------")

# consultar todos los productos cuya descripcion sea Impresora
for prod in coleccion.find( {"descripcion":"Impresora"} ):
    print(prod)
print("------------------")

# consultar todos los productos ordenados por precio ascendente
for prod in coleccion.find().sort("precio", 1):   # 1 ascendente, -1 descendente
    print(prod)
print("------------------")

# consultar todos los productos ordenados por precio descendente
for prod in coleccion.find().sort("precio", -1):
    print(prod)
print("------------------")

# consultar todos los productos comiencen por letra R
for prod in coleccion.find( {"descripcion": {"$regex": "^R"}  } ):
    print(prod)
print("------------------")

# consultar todos los productos que contienen la letra e y el precio es inferior a 50
for prod in coleccion.find( {"descripcion": {"$regex": "e"}, "precio": {"$lt": 50}  }):
    print(prod)
print("------------------")
  
 
'''   ******** Modificar *********  '''
# subir un 10% el precio de la impresora
filtro = {"descripcion": "Impresora"}
nuevo_valor = {"$set": {"precio": {"$multiply": ["$precio", 1.10]}}}
coleccion.update_one(filtro, nuevo_valor)

# Cambiar la descripcion de raton a raton inalambrico
filtro = {"descripcion": "Raton"}
nuevo_valor = {"$set": {"descripcion": "Raton inalambrico" }}
coleccion.update_one(filtro, nuevo_valor)


'''    ******** Eliminar *********   '''
# Borrar todos los scanner
coleccion.delete_one( {"descripcion": "Scanner"} )


# Cerrar la BBDD
conexion.close()