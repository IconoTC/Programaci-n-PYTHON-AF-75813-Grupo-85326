''' Crear la BBDD y la tabla  '''

from pymongo import MongoClient

# Al abrir la conexion
conexion = MongoClient("mongodb://localhost:27017")

# Crear la BBDD
db = conexion['tiendaDB']

# Crear la coleccion de PRODUCTOS
coleccion = db['PRODUCTOS']


# Cerrar la BBDD
conexion.close()